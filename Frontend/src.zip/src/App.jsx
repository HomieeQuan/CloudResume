import { useState, useEffect } from 'react'
import React from 'react'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css'
import axios from 'axios'
import HomePage from './components/home'
import Navbar from './components/navbar'
import Experience from './components/experience'
import Projects from './components/projects'
import Certifications from './components/certs'

function App() {
  // const [count, setCount] = useState(0)
  // const [array, setArray] = useState([])
  const [curPage, setCurPage] = useState('HomePage')
  console.log('Current Page', curPage)



  // const fetchApi = async () => {
  //   const response = await axios.get('http://localhost:8080/api/users')
  //   console.log(response.data.users)
  //   setArray(response.data.users)
  // }
  // useEffect(() => {
  //   fetchApi()
  // }, [])

  return (
    
      <div className="w-full min-h-screen bg-black relative overflow-hidden">
        

        {/* Main content */}
        <div className="relative z-10">

          <Navbar setCurPage={setCurPage} curPage={curPage} />
          

        </div>

        
      </div>
    
  );
};



export default App
