import React from 'react';
import { Link } from 'react-router-dom';


const Navbar = ({ setCurPage, curPage }) => {
    const navItems = [
        'Home', 'Experience', 'Projects', 'Certifications',
    ];
    //   const navItemComponents = [
    //     'HomePage', 'Experience','Projects', 'Certifications', 
    //   ]
    const navItemRoutes = [
        '/', '/experience', '/projects', '/certs'
    ]
    const navItemClasses = "px-3 py-2 text-sm text-white bg-gray-900 bg-opacity-80 rounded-md hover:bg-opacity-100 transition-all duration-300"


    return (
        <>
        <h1>NAV</h1>
            <div className="bg-black w-full">
                <div className="relative overflow-hidden py-4">


                    <div className="max-w-7xl mx-auto px-4">
                        <div className="flex flex-wrap justify-center sm:justify-end gap-2 relative z-10">
                            
                            
                            { navItems.map((item, index) => {


                                <div key={item} className={navItemClasses}>
                                    hello
                                    {console.log(item)}
                                     
                                    <h1>Hello</h1>
                                </div>

                            })
                            }
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Navbar;